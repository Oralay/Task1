#ifndef __REQUEST_H__

void request_handle(int fd);

#endif // __REQUEST_H__
